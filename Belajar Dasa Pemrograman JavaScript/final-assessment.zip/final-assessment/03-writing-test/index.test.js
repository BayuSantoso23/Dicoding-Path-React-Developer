import { sum } from './index.js';

console.log(sum(8,9));