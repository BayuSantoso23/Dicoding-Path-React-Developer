// Deklarasi variabel berdasarkan elemen id
const bookForm = document.getElementById('bookForm');
const unfinishedBooks = document.getElementById('unfinishedBooks');
const finishedBooks = document.getElementById('finishedBooks');

// Membuat array untuk menampung buku
let books = [];

// Ambil data dari localStorage saat halaman dimuat
document.addEventListener('DOMContentLoaded', () => {
  books = JSON.parse(localStorage.getItem('books')) || [];
  renderBooks();
});

// Fungsi untuk menyimpan ke localStorage
function saveToLocalStorage() {
  // Menyimpan dalam format json
  localStorage.setItem('books', JSON.stringify(books));
}

// Menampilkan buku ke rak
function renderBooks() {
  unfinishedBooks.innerHTML = '';
  finishedBooks.innerHTML = '';

  books.forEach((book, index) => {
    const bookElement = document.createElement('div');
    bookElement.classList.add('book-item');
    bookElement.innerHTML = `
      <h3>${book.title}</h3>
      <p>Penulis: ${book.author}</p>
      <p>Tahun: ${book.year}</p>
      <button onclick="deleteBook(${index})">Hapus</button>
      <button onclick="moveBook(${index})">
        ${book.isCompleted ? 'Pindahkan ke Belum Selesai' : 'Pindahkan ke Selesai'}
      </button>
    `;

    if (book.isCompleted) {
      finishedBooks.appendChild(bookElement);
    } else {
      unfinishedBooks.appendChild(bookElement);
    }
  });
}

// Menambahkan buku baru
bookForm.addEventListener('submit', (e) => {
  // Mencegah reload 
  e.preventDefault();

  // Membuat objek buku baru
  const newBook = {
    title: document.getElementById('bookTitle').value,
    author: document.getElementById('bookAuthor').value,
    year: parseInt(document.getElementById('bookYear').value),
    isCompleted: document.getElementById('isCompleted').checked,
  };

  // Menambahkan kedalam array books
  books.push(newBook);

  // Menyimpan data ke local storage dan memperbarui tampilan
  saveToLocalStorage();
  renderBooks();
  bookForm.reset();
});

// Menghapus buku
function deleteBook(index) {
  books.splice(index, 1);
  saveToLocalStorage();
  renderBooks();
}

// Memindahkan buku antar rak
function moveBook(index) {
  books[index].isCompleted = !books[index].isCompleted;
  saveToLocalStorage();
  renderBooks();
}
